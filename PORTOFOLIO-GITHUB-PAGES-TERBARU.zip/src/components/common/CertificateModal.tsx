import React, { useEffect } from 'react';
import { CertificateItem } from '../../types';
import { Button } from './Button';
import { X, ExternalLink, Award, Calendar, Hash } from 'lucide-react';

interface CertificateModalProps {
  certificate: CertificateItem | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  useEffect(() => {
    if (certificate) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [certificate, onClose]);

  if (!certificate) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-dark-950/90 backdrop-blur-xl transition-opacity animate-in fade-in"
      />

      {/* Modal Dialog */}
      <div
        className="relative z-10 w-full max-w-3xl my-auto rounded-3xl bg-dark-900 border border-white/10 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.8),0_0_40px_rgba(168,85,247,0.2)] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-dark-800/80 hover:bg-dark-700 text-slate-300 hover:text-white border border-white/10 transition-colors"
          aria-label="Tutup"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Certificate Image in Lightbox */}
        <div className="relative aspect-[16/10] bg-dark-950 overflow-hidden border-b border-white/10 group">
          <img
            src={certificate.image}
            alt={certificate.title}
            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-transparent to-transparent pointer-events-none" />
        </div>

        {/* Certificate Details */}
        <div className="p-6 sm:p-8 space-y-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-mono uppercase mb-3">
              <Award className="w-3.5 h-3.5 text-purple-400" />
              Verified Credential
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-heading text-white">
              {certificate.title}
            </h3>
            <p className="text-slate-400 text-sm mt-1">
              Diterbitkan oleh: <span className="text-cyan-400 font-semibold">{certificate.issuer}</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-2 border-t border-white/5">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              Tahun: {certificate.date}
            </span>
            <span className="flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-purple-400" />
              ID: {certificate.credentialId}
            </span>
          </div>

          {/* Skills Covered */}
          <div>
            <h4 className="text-xs uppercase font-mono tracking-wider text-slate-400 mb-2">
              Kompetensi & Teknologi Tervalidasi
            </h4>
            <div className="flex flex-wrap gap-2">
              {certificate.skills.map((skill, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-dark-800 text-slate-300 text-xs border border-white/5"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Verification Link */}
          <div className="pt-3">
            <Button
              href={certificate.verifyUrl}
              target="_blank"
              variant="outline"
              size="md"
              icon={<ExternalLink className="w-4 h-4" />}
            >
              Verifikasi Kredensial Resmi
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
