import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  href?: string;
  target?: string;
  rel?: string;
  isLoading?: boolean;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'right',
  href,
  target,
  rel,
  isLoading = false,
  fullWidth = false,
  className = '',
  disabled,
  ...rest
}) => {
  const baseClasses = 'relative inline-flex items-center justify-center font-heading font-medium tracking-wide transition-all duration-300 rounded-xl overflow-hidden group select-none active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none disabled:active:scale-100';

  const sizeClasses = {
    sm: 'text-xs px-3.5 py-2 gap-1.5',
    md: 'text-sm px-5 py-2.5 gap-2',
    lg: 'text-base px-7 py-3.5 gap-2.5 font-semibold',
  };

  const variantClasses = {
    primary: `
      bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-500 text-dark-950 font-bold
      shadow-[0_0_20px_-3px_rgba(0,240,255,0.4)] hover:shadow-[0_0_30px_2px_rgba(0,240,255,0.6)]
      hover:from-cyan-300 hover:to-blue-400
      border border-cyan-300/40
    `,
    outline: `
      bg-dark-900/60 backdrop-blur-md text-cyan-300
      border border-cyan-500/40 hover:border-cyan-400
      hover:bg-cyan-500/10 hover:shadow-[0_0_20px_-5px_rgba(0,240,255,0.3)]
    `,
    secondary: `
      bg-white/5 backdrop-blur-md text-slate-200
      border border-white/10 hover:border-white/20
      hover:bg-white/10 hover:text-white
    `,
    ghost: `
      bg-transparent text-slate-300 hover:text-cyan-300
      hover:bg-cyan-500/10
    `,
  };

  const widthClass = fullWidth ? 'w-full' : '';

  const content = (
    <>
      {/* Light sheen effect on hover for primary/outline buttons */}
      <span className="absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000 ease-in-out pointer-events-none" />

      {isLoading ? (
        <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
      ) : icon && iconPosition === 'left' ? (
        <span className="transition-transform duration-300 group-hover:-translate-x-0.5">{icon}</span>
      ) : null}

      <span className="relative z-10">{children}</span>

      {!isLoading && icon && iconPosition === 'right' && (
        <span className="transition-transform duration-300 group-hover:translate-x-1">{icon}</span>
      )}
    </>
  );

  if (href) {
    return (
      <a
        href={href}
        target={target}
        rel={target === '_blank' ? (rel || 'noopener noreferrer') : rel}
        className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${widthClass} ${className}`}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${widthClass} ${className}`}
      disabled={disabled || isLoading}
      {...rest}
    >
      {content}
    </button>
  );
};
