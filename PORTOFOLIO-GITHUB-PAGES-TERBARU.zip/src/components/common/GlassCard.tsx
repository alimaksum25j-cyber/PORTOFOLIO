import React, { useRef, useState } from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: 'cyan' | 'purple' | 'none';
  tiltEffect?: boolean;
  borderHover?: boolean;
  cornerAccents?: boolean;
  onClick?: () => void;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  glowColor = 'cyan',
  tiltEffect = false,
  borderHover = true,
  cornerAccents = false,
  onClick,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [transformStyle, setTransformStyle] = useState<string>('');

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!tiltEffect || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -6; // max 6 deg
    const rotateY = ((x - centerX) / centerX) * 6;

    setTransformStyle(`perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.01, 1.01, 1.01)`);
  };

  const handleMouseLeave = () => {
    if (!tiltEffect) return;
    setTransformStyle('perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)');
  };

  const glowShadow = {
    cyan: 'hover:shadow-[0_10px_35px_-10px_rgba(0,240,255,0.25)]',
    purple: 'hover:shadow-[0_10px_35px_-10px_rgba(168,85,247,0.25)]',
    none: '',
  }[glowColor];

  const borderHoverClass = borderHover
    ? glowColor === 'purple'
      ? 'hover:border-purple-500/40'
      : 'hover:border-cyan-400/40'
    : '';

  return (
    <div
      ref={cardRef}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: transformStyle,
        transition: 'transform 0.15s ease-out, border-color 0.3s ease, box-shadow 0.3s ease',
      }}
      className={`
        relative rounded-2xl bg-dark-850/70 backdrop-blur-xl border border-white/10
        transition-all duration-300 ${glowShadow} ${borderHoverClass} ${onClick ? 'cursor-pointer' : ''} ${className}
      `}
    >
      {/* Corner Tech Accents */}
      {cornerAccents && (
        <>
          <span className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400 rounded-tl pointer-events-none" />
          <span className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400 rounded-tr pointer-events-none" />
          <span className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400 rounded-bl pointer-events-none" />
          <span className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400 rounded-br pointer-events-none" />
        </>
      )}

      {children}
    </div>
  );
};
