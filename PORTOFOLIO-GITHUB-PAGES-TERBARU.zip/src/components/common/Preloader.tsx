import React, { useEffect, useState } from 'react';

interface PreloaderProps {
  onComplete: () => void;
}

const statusMessages = [
  "Initializing Cyber Engine...",
  "Compiling WebGL Shaders...",
  "Loading 3D Meshes & Geometry...",
  "Calibrating Spatial Coordinates...",
  "Welcome to Ali Maksum Universe."
];

export const Preloader: React.FC<PreloaderProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [statusIdx, setStatusIdx] = useState(0);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            setIsFading(true);
            setTimeout(onComplete, 700);
          }, 300);
          return 100;
        }

        // Random jump increments for realistic boot effect
        const jump = Math.floor(Math.random() * 8) + 3;
        const next = Math.min(100, prev + jump);

        // Update status text based on progress
        const messageIndex = Math.min(
          statusMessages.length - 1,
          Math.floor((next / 100) * statusMessages.length)
        );
        setStatusIdx(messageIndex);

        return next;
      });
    }, 60);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050510] transition-opacity duration-700 ease-out select-none ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Cyber Grid */}
      <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />
      <div className="absolute w-[500px] h-[500px] rounded-full bg-cyan-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute w-[400px] h-[400px] rounded-full bg-purple-600/10 blur-[100px] pointer-events-none" />

      {/* Center Cyber Ring & Logo */}
      <div className="relative mb-8 flex items-center justify-center">
        {/* Outer rotating ring */}
        <div className="w-32 h-32 rounded-full border border-dashed border-cyan-400/40 animate-[spin_10s_linear_infinite]" />
        
        {/* Inner reverse rotating ring */}
        <div className="absolute w-24 h-24 rounded-full border border-cyan-500/30 border-t-purple-500 animate-[spin_5s_linear_infinite_reverse]" />

        {/* Core Initials */}
        <div className="absolute flex flex-col items-center justify-center">
          <span className="font-heading font-extrabold text-2xl tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 drop-shadow-[0_0_15px_rgba(0,240,255,0.7)]">
            AM
          </span>
          <span className="w-1.5 h-1.5 mt-0.5 rounded-full bg-cyan-400 animate-ping" />
        </div>
      </div>

      {/* Progress Counter */}
      <div className="relative z-10 flex flex-col items-center max-w-xs w-full px-6 text-center">
        <div className="flex items-baseline justify-between w-full mb-2">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
            System Boot
          </span>
          <span className="font-mono text-cyan-400 font-bold text-lg drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]">
            {progress}%
          </span>
        </div>

        {/* Progress Bar Container */}
        <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden relative p-[1px] border border-cyan-500/20">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-teal-300 to-purple-500 transition-all duration-150 ease-out shadow-[0_0_12px_#00f0ff]"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Status Message */}
        <p className="mt-4 text-xs font-mono text-slate-400 tracking-wide h-4">
          {statusMessages[statusIdx]}
        </p>
      </div>
    </div>
  );
};
