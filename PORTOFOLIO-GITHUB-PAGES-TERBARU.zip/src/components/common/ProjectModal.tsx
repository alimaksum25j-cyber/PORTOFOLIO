import React, { useEffect, useState } from 'react';
import { ProjectItem } from '../../types';
import { Button } from './Button';
import { X, ExternalLink, Github, CheckCircle2, Layers, Cpu, Eye } from 'lucide-react';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  const [selectedImage, setSelectedImage] = useState<string>('');

  useEffect(() => {
    if (project) {
      setSelectedImage(project.thumbnail);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-dark-950/85 backdrop-blur-xl transition-opacity animate-in fade-in"
      />

      {/* Modal Dialog */}
      <div
        className="relative z-10 w-full max-w-4xl my-auto rounded-3xl bg-dark-900 border border-white/10 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.8),0_0_40px_rgba(0,240,255,0.15)] overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-dark-800/80 hover:bg-dark-700 text-slate-300 hover:text-white border border-white/10 transition-colors"
          aria-label="Tutup Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8">
          {/* Main Visual Image & Gallery Preview */}
          <div className="space-y-3">
            <div className="relative aspect-video rounded-2xl overflow-hidden border border-white/10 bg-dark-950 group">
              <img
                src={selectedImage || project.thumbnail}
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-950/80 via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-slate-300 pointer-events-none">
                <span className="px-3 py-1 rounded-full bg-dark-900/80 backdrop-blur-md border border-white/10 flex items-center gap-1.5 font-mono">
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  Pratinjau Interaktif
                </span>
                <span className="font-mono text-cyan-400">High-Fidelity Render</span>
              </div>
            </div>

            {/* Gallery Thumbnails (if multiple) */}
            {project.gallery && project.gallery.length > 1 && (
              <div className="flex gap-2.5 overflow-x-auto pb-1">
                {project.gallery.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden border-2 transition-all flex-shrink-0 ${
                      selectedImage === img
                        ? 'border-cyan-400 shadow-[0_0_10px_rgba(0,240,255,0.5)]'
                        : 'border-white/10 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`Gallery ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Header Info */}
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-wider">
                {project.category}
              </span>
              {project.featured && (
                <span className="px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-mono uppercase tracking-wider">
                  Featured Project
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-white mb-2">
              {project.title}
            </h2>
            <p className="text-slate-400 text-base font-medium">
              {project.tagline}
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap gap-4 pt-2 border-t border-b border-white/10 py-5">
            <Button
              href={project.liveUrl}
              target="_blank"
              variant="primary"
              size="md"
              icon={<ExternalLink className="w-4 h-4" />}
            >
              Lihat Live Demo
            </Button>
            <Button
              href={project.githubUrl}
              target="_blank"
              variant="outline"
              size="md"
              icon={<Github className="w-4 h-4" />}
            >
              Source Code (GitHub)
            </Button>
          </div>

          {/* Key Metric Stats (if any) */}
          {project.stats && project.stats.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {project.stats.map((st, i) => (
                <div key={i} className="p-4 rounded-xl bg-dark-800/50 border border-white/5">
                  <div className="text-xl sm:text-2xl font-bold font-mono text-cyan-400 drop-shadow-[0_0_8px_rgba(0,240,255,0.4)]">
                    {st.value}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">{st.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Long Description */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold font-heading text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Tentang Proyek Ini
            </h3>
            <p className="text-slate-300 leading-relaxed text-sm sm:text-base">
              {project.longDescription}
            </p>
          </div>

          {/* Key Features */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold font-heading text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              Fitur & Kemampuan Unggulan
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {project.features.map((feature, i) => (
                <div
                  key={i}
                  className="flex items-start gap-2.5 p-3 rounded-xl bg-dark-850/60 border border-white/5 text-slate-300 text-sm"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-2 flex-shrink-0 shadow-[0_0_6px_#00f0ff]" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack Pills */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold font-heading text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Teknologi Yang Dipakai
            </h3>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 rounded-xl bg-dark-800 text-cyan-300 border border-cyan-500/20 text-xs font-mono font-medium shadow-[0_0_8px_rgba(0,240,255,0.1)]"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
