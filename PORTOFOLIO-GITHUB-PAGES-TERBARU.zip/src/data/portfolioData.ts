import { ProjectItem, SkillCategory, ExperienceItem, CertificateItem, StatisticItem } from '../types';

export const personalInfo = {
  name: "Muhammad Ali Ma'sum",
  shortName: "Ali",
  initials: "AL",
  title: "Creative Fullstack Developer & 3D WebGL Specialist",
  tagline: "Bridging the gap between artistic 3D immersion and robust fullstack web engineering.",
  bio: "Halo! Saya Ali Maksum, seorang Creative Fullstack Developer dan spesialis 3D WebGL dengan pengalaman lebih dari 1 tahun dalam membangun platform web interaktif. Menggabungkan estetika visual futuristik dengan arsitektur kode modern untuk menciptakan pengalaman digital yang tidak terlupakan.",
  location: "SIdoarjo,Indonesia",
  email: "alimaksum25j@gmail.com",
  phone: "+62 0813 7298 064",
  whatsappUrl: "https://wa.me/628137298064",
  githubUrl: "https://github.com/alimaksum25j-cyber",
  linkedinUrl: "https://linkedin.com/in/alimaksum",
  instagramUrl: "https://www.instagram.com/alima.sum_",
  twitterUrl: "https://twitter.com/alimaksum_dev",
  availableForHire: true,
  yearsOfExperience: "4+",
  completedProjects: "35+",
};


export const skillCategories: SkillCategory[] = [
  {
    id: "frontend",
    title: "Frontend Development",
    subtitle: "Antarmuka & pengalaman web",
    count: 8,
    iconName: "code",
    linkHref: "#projects",
    skills: [
      { name: "HTML, CSS & JavaScript", level: 90, highlight: true },
      { name: "React & TypeScript", level: 82 },
      { name: "Tailwind CSS", level: 85 },
      { name: "Responsive Web Design", level: 88 }
    ]
  },
  {
    id: "creative",
    title: "Creative Development",
    subtitle: "Visual interaktif & animasi",
    count: 6,
    iconName: "award",
    linkHref: "#projects",
    skills: [
      { name: "Three.js & WebGL", level: 75 },
      { name: "React Three Fiber", level: 72 },
      { name: "GSAP Animation", level: 80 },
      { name: "Blender 3D", level: 65 }
    ]
  },
  {
    id: "tools",
    title: "Tools & Technologies",
    subtitle: "Teknologi pendukung proyek",
    count: 10,
    iconName: "certificate",
    linkHref: "#experience",
    skills: [
      { name: "Git & GitHub", level: 78 },
      { name: "Node.js", level: 70 },
      { name: "PostgreSQL", level: 65 },
      { name: "Python", level: 68 }
    ]
  }
];

export const statisticsData: StatisticItem[] = [
  {
    value: 1,
    suffix: "+",
    label: "Proyek Terselesaikan",
    description: "Web 3D, SaaS Fullstack & Mobile apps",
  },
  {
    value: 2,
    suffix: "+",
    label: "Tahun Pengalaman",
    description: "Pengembangan software & visual interaktif",
  },
  {
    value: 10,
    suffix: "+",
    label: "Teknologi Dikuasai",
    description: "Frontend, Three.js, Backend & Cloud",
  },
  {
    value: 89	,
    suffix: "%",
    label: "Kepuasan Klien",
    description: "Kualitas kode & performa terjamin",
  },
];

export const marqueeTechnologies = [
  "React", "TypeScript", "Three.js", "React Three Fiber", "Tailwind CSS",
  "Next.js", "GSAP", "GLSL Shaders", "Node.js", "PostgreSQL",
  "Blender 3D", "WebGL", "Lenis Scroll", "Docker", "Python",
  "Prisma", "Zustand", "Vite", "GraphQL", "Redis"
];

export const projectsData: ProjectItem[] = [
  {
    id: "cyber-automotive-3d",
    title: "Web Bendahara OSIS MAN 3 Jombang",
    category: "Web 3D",
    tagline: "Interactive 3D real-time vehicle customizer with realistic PBR materials and shader effects.",
    description: "Website Bendahara OSIS MAN 3 Jombang merupakan aplikasi berbasis web yang dikembangkan menggunakan Google Apps Script untuk membantu pengelolaan keuangan organisasi secara digital. Website ini memudahkan pencatatan pemasukan, pengeluaran, serta pemantauan saldo kas OSIS secara lebih praktis, terstruktur, dan transparan.",
    longDescription: "Website Bendahara OSIS MAN 3 Jombang merupakan aplikasi berbasis web yang dikembangkan menggunakan Google Apps Script untuk membantu pengelolaan keuangan organisasi secara digital. Website ini memudahkan pencatatan pemasukan, pengeluaran, serta pemantauan saldo kas OSIS secara lebih praktis, terstruktur, dan transparan.",
    thumbnail: "https://cdn.imagetourls.com/uploads/tyImg/17hEEbcGq.png",
    gallery: [
      "https://cdn.imagetourls.com/uploads/tyImg/16ncoVaZ1.png",
      "https://cdn.imagetourls.com/uploads/tyImg/2EyNPmHj.png",
      "https://cdn.imagetourls.com/uploads/tyImg/xMJe6bFJ.png",
      "https://cdn.imagetourls.com/uploads/tyImg/1enhyejHG.png",
      "https://cdn.imagetourls.com/uploads/tyImg/kHbB3MUU.png"
    ],
    technologies: ["React", "Three.js", "script.google", "GLSL", "Tailwind CSS", "Zustand"],
    features: [
      "Dashboard Keuangan – Menampilkan ringkasan pemasukan, pengeluaran, dan saldo kas.",
      "Pencatatan Pemasukan – Mencatat setiap uang yang masuk ke kas OSIS.",
      "Manajemen Saldo – Menghitung saldo kas secara otomatis.",
      "Efisien: Mempermudah pengelolaan keuangan tanpa pencatatan manual.",
      "Transparan: Memudahkan pemantauan arus kas OSIS."
    ],
    stats: [
      { label: "Performance", value: "60 FPS" },
      { label: "Asset Compression", value: "70%" },
    ],
    liveUrl: "https://script.google.com/macros/s/AKfycbw-mzP2NzDL7JWKTvZaGQd4peupVZWO6Sd2hDgJLiZcZoY9Ff7r5ZTb6OpkgAbQZtgl/exec",
    githubUrl: "https://github.com/alimaksum25j-cyber",
    featured: true,
  },
];

export const experienceData: ExperienceItem[] = [
  {
    id: "exp-1",
    period: "2021 - Sekarang",
    role: "Senior Creative Fullstack & 3D WebGL Developer",
    company: "Metaverse Creative Studio",
    location: "Jakarta (Hybrid / Remote)",
    type: "experience",
    featuredBadge: "Current Role",
    description: [
      "Memimpin arsitektur dan pengembangan pengalaman web 3D interaktif untuk brand internasional terkemuka.",
      "Mengoptimalkan performa Three.js dan shader WebGL hingga konsisten mencapai 60 FPS di perangkat mobile.",
      "Membangun backend microservices dan integrasi API GraphQL berkecepatan tinggi."
    ],
    techStack: ["React", "Three.js", "R3F", "GLSL", "Node.js", "PostgreSQL", "Docker"]
  },
  {
    id: "exp-2",
    period: "2027 - 2030",
    role: "Sarjana Teknik,S.TS1 Teknik ELEKTRO ",
    company: "Intitut Teknologi SepuluhNopember",
    location: "Surabaya, Indonesia",
    type: "experience",
    description: [
      "Mengembangkan aplikasi web SaaS berbasis React dan Node.js yang melayani puluhan ribu pengguna aktif harian.",
      "Merancang antarmuka dashboard interaktif dengan Tailwind CSS dan animasi transisi GSAP yang halus.",
      "Meningkatkan skor Lighthouse website perusahaan dari 65 menjadi 98+ dengan teknik lazy loading dan code splitting."
    ],
    techStack: ["TypeScript", "React", "Next.js", "Node.js", "Tailwind CSS", "MongoDB", "Redis"]
  },
  {
    id: "exp-3",
    period: "2024 - 2026",
    role: "Pelajar",
    company: "MAN 3 JOmbang",
    location: "Jombang, Indonesia",
    type: "experience",
    description: [
      "Menerjemahkan rancangan wireframe dan desain Figma menjadi kode responsif pixel-perfect.",
      "Membangun interaksi mikro dan sistem komponen yang dipakai ulang di lebih dari 5 proyek klien.",
      "Mulai mengintegrasikan visual 3D Three.js sederhana ke dalam landing page komersial."
    ],
    techStack: ["JavaScript", "React", "CSS3 / Sass", "Three.js", "GSAP", "Figma"]
  },
  {
    id: "edu-1",
    period: "2021 - 2023",
    role: "Pelajar ",
    company: "MTSN 3 JOMBANG",
    location: "Jombang, Indonesia",
    type: "education",
    featuredBadge: "RATA-RATA 95,5",
    description: [
      "Fokus pada Rekayasa Perangkat Lunak, Grafika Komputer (Computer Graphics), dan Sistem Terdistribusi.",
      "Publikasi tugas akhir: 'Implementasi WebGL dan Custom Shader untuk Visualisasi Data Spasial Interaktif'.",
      "Juara 1 Hackathon Nasional Pengembangan Aplikasi Web Interaktif Kreatif."
    ],
    techStack: ["Computer Graphics", "Algorithms & Data Structures", "Software Engineering", "Mathematics"]
  }
];

export const certificatesData: CertificateItem[] = [
  {
    id: "cert-1",
    title: "CSS And Javascript Crash Courser",
    issuer: "UDEMY",
    date: "2026",
    credentialId: "TH-JRN-984210",
    image: "https://cdn.imagetourls.com/uploads/tyImg/qQojqFQg.webp",
    verifyUrl: "https://threejs-journey.com",
    skills: ["Three.js", "CSS", "Javascript", "Blender Workflow", "Physics (Cannon.js)"]
  },
  {
    id: "cert-2",
    title: "Ethically Hack the Planet Part 2",
    issuer: "UDEMY",
    date: "2026",
    credentialId: "META-FS-847291",
    image: "https://cdn.imagetourls.com/uploads/tyImg/6jvbnl2d.webp",
    verifyUrl: "https://coursera.org",
    skills: ["React Advanced", "Python & Django", "CSS","Javascript", "CI/CD", "REST APIs"]
  },
  ];

export const navigationLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Skills", href: "#skills" },
  { name: "Projects", href: "#projects" },
  { name: "Timeline", href: "#experience" },
  { name: "Certificates", href: "#certificates" },
  { name: "Contact", href: "#contact" },
];
