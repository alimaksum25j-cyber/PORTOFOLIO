import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

interface SceneProps {
  mouse: { x: number; y: number };
  isReducedMotion: boolean;
}

// Interactive floating cyber geometric core
function CyberCore({ mouse, isReducedMotion }: SceneProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef1 = useRef<THREE.Mesh>(null);
  const ringRef2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (isReducedMotion) return;

    const t = state.clock.getElapsedTime();

    if (meshRef.current) {
      // Gentle continuous rotation
      meshRef.current.rotation.x = t * 0.25;
      meshRef.current.rotation.y = t * 0.35;

      // Mouse damping reaction
      meshRef.current.position.x = THREE.MathUtils.lerp(
        meshRef.current.position.x,
        mouse.x * 0.8,
        0.05
      );
      meshRef.current.position.y = THREE.MathUtils.lerp(
        meshRef.current.position.y,
        mouse.y * 0.8,
        0.05
      );
    }

    if (ringRef1.current) {
      ringRef1.current.rotation.x = t * 0.4 + Math.PI / 4;
      ringRef1.current.rotation.y = -t * 0.3;
    }

    if (ringRef2.current) {
      ringRef2.current.rotation.x = -t * 0.25 + Math.PI / 3;
      ringRef2.current.rotation.z = t * 0.45;
    }
  });

  return (
    <group>
      {/* Central Distorted Futuristic Torus Knot */}
      <Float speed={2} rotationIntensity={0.8} floatIntensity={1.2}>
        <mesh ref={meshRef} position={[0, 0, 0]} scale={1.2}>
          <torusKnotGeometry args={[1, 0.32, 128, 32, 2, 3]} />
          <MeshDistortMaterial
            color="#00f0ff"
            roughness={0.15}
            metalness={0.9}
            distort={0.25}
            speed={1.5}
            emissive="#004466"
            emissiveIntensity={0.6}
            wireframe={false}
          />
        </mesh>
      </Float>

      {/* Orbiting Cyber Ring 1 (Cyan Wireframe) */}
      <mesh ref={ringRef1} scale={2.2}>
        <torusGeometry args={[1, 0.015, 16, 100]} />
        <meshStandardMaterial
          color="#00f0ff"
          emissive="#00f0ff"
          emissiveIntensity={1.5}
          wireframe
        />
      </mesh>

      {/* Orbiting Cyber Ring 2 (Purple Neon) */}
      <mesh ref={ringRef2} scale={2.6}>
        <torusGeometry args={[1, 0.02, 16, 100]} />
        <meshStandardMaterial
          color="#a855f7"
          emissive="#a855f7"
          emissiveIntensity={1.8}
        />
      </mesh>
    </group>
  );
}

// Orbiting spatial particles
function ParticleField({ count = 350, mouse }: { count?: number; mouse: { x: number; y: number } }) {
  const pointsRef = useRef<THREE.Points>(null);

  const [positions, colors] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const colorCyan = new THREE.Color('#00f0ff');
    const colorPurple = new THREE.Color('#a855f7');
    const colorWhite = new THREE.Color('#ffffff');

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      const radius = 2.5 + Math.random() * 4.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      pos[i3] = radius * Math.sin(phi) * Math.cos(theta);
      pos[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      pos[i3 + 2] = radius * Math.cos(phi);

      const mixedColor = Math.random() > 0.5 ? colorCyan : Math.random() > 0.5 ? colorPurple : colorWhite;
      col[i3] = mixedColor.r;
      col[i3 + 1] = mixedColor.g;
      col[i3 + 2] = mixedColor.b;
    }

    return [pos, col];
  }, [count]);

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.getElapsedTime() * 0.04 + mouse.x * 0.1;
      pointsRef.current.rotation.x = mouse.y * 0.08;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={colors.length / 3}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.035}
        vertexColors
        transparent
        opacity={0.85}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

interface Hero3DCanvasProps {
  mouse: { x: number; y: number };
  isReducedMotion: boolean;
}

export const Hero3DCanvas: React.FC<Hero3DCanvasProps> = ({ mouse, isReducedMotion }) => {
  return (
    <div className="w-full h-full relative select-none pointer-events-auto">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 45 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      >
        <ambientLight intensity={0.4} />
        <pointLight position={[5, 5, 5]} intensity={2} color="#00f0ff" />
        <pointLight position={[-5, -5, -3]} intensity={1.5} color="#a855f7" />
        <directionalLight position={[0, 4, 3]} intensity={1} color="#ffffff" />

        <CyberCore mouse={mouse} isReducedMotion={isReducedMotion} />
        <ParticleField count={isReducedMotion ? 100 : 350} mouse={mouse} />
      </Canvas>
    </div>
  );
};
