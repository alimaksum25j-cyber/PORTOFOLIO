import React, { useState, useEffect } from 'react';
import { personalInfo } from '../data/portfolioData';
import { Button } from '../components/common/Button';
import { Hero3DCanvas } from './Hero3DCanvas';
import { useMousePosition } from '../hooks/useMousePosition';
import { useReducedMotion } from '../hooks/useReducedMotion';
import { ArrowDown, Code2, Download, Sparkles, ChevronDown } from 'lucide-react';

const rolesList = [
  "Creative Fullstack Developer",
  "3D WebGL Specialist",
  "Interactive Three.js Architect",
  "High-Performance Web Engineer"
];

export const HeroSection: React.FC = () => {
  const mouse = useMousePosition();
  const isReducedMotion = useReducedMotion();

  // Typing / text cycle effect
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentRole = rolesList[roleIndex];
    const typingSpeed = isDeleting ? 40 : 80;

    const timer = setTimeout(() => {
      if (!isDeleting) {
        setDisplayText(currentRole.substring(0, displayText.length + 1));
        if (displayText.length + 1 === currentRole.length) {
          setTimeout(() => setIsDeleting(true), 1800);
        }
      } else {
        setDisplayText(currentRole.substring(0, displayText.length - 1));
        if (displayText.length === 0) {
          setIsDeleting(false);
          setRoleIndex((prev) => (prev + 1) % rolesList.length);
        }
      }
    }, typingSpeed);

    return () => clearTimeout(timer);
  }, [displayText, isDeleting, roleIndex]);

  const handleScrollToProjects = (e: React.MouseEvent) => {
    e.preventDefault();
    const elem = document.getElementById('projects');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDownloadCV = () => {
    // Generate a clean text CV download or link
    const cvContent = `
======================================================
ALI MAKSUM - CREATIVE FULLSTACK DEVELOPER & 3D SPECIALIST
======================================================
Email: alimaksum.dev@gmail.com
GitHub: https://github.com/alimaksum
Portfolio: https://alimaksum.dev/
Location: Indonesia (Remote Worldwide)

SUMMARY:
Creative Fullstack Developer and 3D WebGL Specialist with 4+ years of
experience building high-performance interactive web applications,
immersive Three.js 3D environments, and robust microservice architectures.

CORE SKILLS:
- Frontend: React, Next.js, TypeScript, Tailwind CSS, Vue, Zustand
- 3D & Graphics: Three.js, React Three Fiber, GLSL Shaders, WebGL, GSAP, Blender
- Backend: Node.js, Express, Python, PostgreSQL, Prisma, MongoDB, Redis, Docker
- Architecture: REST, GraphQL, Performance Optimization, Lighthouse 95+

EXPERIENCE:
- Senior Creative Fullstack & 3D WebGL Developer (Metaverse Creative Studio, 2023 - Present)
- Fullstack Web Developer (CyberTech Innovations, 2021 - 2023)
- Frontend & UI/UX Developer (Digital Nexus Agency, 2020 - 2021)

EDUCATION:
- B.S. in Computer Science (IPK 3.88 / Cum Laude)
======================================================
    `.trim();

    const blob = new Blob([cvContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CV_Ali_Maksum_Fullstack_3D_Developer.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#050510]"
    >
      {/* Background Ambience & Cyber Grid */}
      <div className="absolute inset-0 cyber-grid opacity-25 pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Text Column (Col 7) */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
            {/* Availability Badge */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-dark-850/80 border border-cyan-500/20 backdrop-blur-md shadow-[0_0_15px_rgba(0,240,255,0.15)]">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
              </span>
              <span className="text-xs font-mono text-cyan-300 tracking-wide font-medium">
                Halo, saya <span className="text-white font-bold">{personalInfo.name}</span> 👋
              </span>
              <span className="hidden sm:inline text-xs text-slate-500">|</span>
              <span className="hidden sm:inline text-xs font-mono text-slate-400">
                Available for Q1 Projects
              </span>
            </div>

            {/* Main Name & Title */}
            <div>
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold font-heading tracking-tight text-white leading-[1.08]">
                {personalInfo.name}
              </h1>

              {/* Dynamic Typing Title */}
              <div className="mt-4 flex items-center min-h-[44px] sm:min-h-[52px]">
                <span className="text-xl sm:text-3xl lg:text-4xl font-extrabold font-heading text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-teal-300 to-purple-400 drop-shadow-[0_0_20px_rgba(0,240,255,0.4)]">
                  {displayText}
                </span>
                <span className="inline-block w-1 h-7 sm:h-9 bg-cyan-400 ml-1.5 animate-pulse rounded-sm shadow-[0_0_8px_#00f0ff]" />
              </div>
            </div>

            {/* Short Bio Description (2 Sentences) */}
            <p className="text-base sm:text-lg text-slate-300 font-normal leading-relaxed max-w-xl">
              Membangun pengalaman web generasi masa depan yang memadukan keindahan visual 3D interaktif Three.js dengan arsitektur fullstack yang scalable. Berfokus pada estetika futuristik bernuansa cyber, fluiditas 60 FPS, dan performa tinggi.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <Button
                href="#projects"
                onClick={handleScrollToProjects}
                variant="primary"
                size="lg"
                icon={<Code2 className="w-5 h-5" />}
              >
                Lihat Proyek
              </Button>

              <Button
                onClick={handleDownloadCV}
                variant="outline"
                size="lg"
                icon={<Download className="w-5 h-5" />}
              >
                Download CV
              </Button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="pt-6 border-t border-white/10 flex flex-wrap items-center gap-6 sm:gap-10 text-xs font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>3D WebGL / Three.js</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>React & Next.js Fullstack</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>60 FPS Animation</span>
              </div>
            </div>
          </div>

          {/* Right 3D Column (Col 5) */}
          <div className="lg:col-span-5 h-[380px] sm:h-[460px] lg:h-[520px] relative flex items-center justify-center">
            {/* Ambient Back Glow for Canvas */}
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 via-purple-600/15 to-transparent rounded-3xl blur-2xl pointer-events-none" />

            {/* Interactive 3D Canvas */}
            <Hero3DCanvas
              mouse={{ x: mouse.normalizedX, y: mouse.normalizedY }}
              isReducedMotion={isReducedMotion}
            />

            {/* Floating 3D Badge */}
            <div className="absolute bottom-4 right-4 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-dark-900/80 backdrop-blur-md border border-cyan-500/30 text-[11px] font-mono text-cyan-300 shadow-[0_0_15px_rgba(0,240,255,0.2)] select-none">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
              <span>Three.js Interactive Core</span>
            </div>
          </div>

        </div>
      </div>

      {/* Animated Scroll Down Indicator */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors select-none group"
      >
        <span className="text-[11px] font-mono uppercase tracking-widest text-slate-500 group-hover:text-cyan-400 transition-colors">
          Scroll Down
        </span>
        <div className="w-5 h-8 rounded-full border-2 border-slate-600 group-hover:border-cyan-400 flex items-start justify-center p-1 transition-colors">
          <div className="w-1 h-2 rounded-full bg-cyan-400 animate-bounce" />
        </div>
      </a>
    </section>
  );
};
