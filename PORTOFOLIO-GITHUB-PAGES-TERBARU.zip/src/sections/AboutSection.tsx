import React, { useState, useEffect, useRef } from 'react';
import { personalInfo, statisticsData } from '../data/portfolioData';
import { SectionTitle } from '../components/common/SectionTitle';
import { GlassCard } from '../components/common/GlassCard';
import { Button } from '../components/common/Button';
import { Sparkles, Terminal, Cpu, Globe2, ShieldCheck, Mail } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Trigger count-up animation when section is visible
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHasAnimated(true);
        }
      },
      { threshold: 0.25 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#050510] overflow-hidden"
    >
      {/* Background Subtle Gradient Blobs */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionTitle
          badge="Eksplorasi Profil"
          title="Mengenal Lebih Dekat"
          highlightText="Ali Maksum"
          subtitle="Menggabungkan sains pemrograman dan seni visual 3D untuk menciptakan ekosistem digital yang berkesan."
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Column 1: 3D Tilt Cyber Profile Photo Frame (5 Cols) */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group max-w-sm sm:max-w-md w-full">
              {/* Outer Neon Glow Layer */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-cyan-500 via-purple-600 to-blue-500 opacity-40 blur-xl group-hover:opacity-75 transition-opacity duration-500" />

              {/* Photo Card Container */}
              <GlassCard
                tiltEffect={true}
                cornerAccents={true}
                glowColor="cyan"
                className="p-3 sm:p-4 bg-dark-900/90"
              >
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-dark-950">
                  {/* High quality aesthetic developer portrait placeholder */}
                  <img
                    src={`${import.meta.env.BASE_URL}profile.jpg`}
                    alt={personalInfo.name}
                    onError={(e) => {
                      e.currentTarget.src = "https://cdn.imagetourls.com/uploads/tyImg/NjxbC7zo.jpg";
                    }}
                    className="w-full h-full object-cover object-center grayscale contrast-110 group-hover:grayscale-0 group-hover:contrast-100 group-hover:scale-105 transition-all duration-700 ease-out"
                  />

                  {/* Gradient overlays */}
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-950 via-dark-950/20 to-transparent opacity-80" />
                  <div className="absolute inset-0 bg-cyan-500/10 mix-blend-overlay group-hover:opacity-0 transition-opacity" />

                  {/* Top Status Pill */}
                  <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-dark-900/80 backdrop-blur-md border border-white/10 text-xs font-mono text-cyan-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Active Developer</span>
                  </div>

                  {/* Bottom Tech Caption */}
                  <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-dark-900/85 backdrop-blur-md border border-white/10 flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold font-heading text-white">
                        {personalInfo.name}
                      </h4>
                      <p className="text-[11px] font-mono text-cyan-400">
                        {personalInfo.title}
                      </p>
                    </div>
                    <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                      <Terminal className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Column 2: Bio, Philosophy & Statistics (7 Cols) */}
          <div className="lg:col-span-7 space-y-8 text-left">
            <div className="space-y-4">
              <h3 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">
                Membangun Pengalaman Digital yang{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
                  Melampaui Ekspektasi
                </span>
              </h3>

              <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
                {personalInfo.bio}
              </p>

              <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                Dengan latar belakang kuat di bidang Computer Science dan spesialisasi WebGL, saya percaya bahwa interaksi web masa depan tidak hanya statis 2 dimensi, tetapi harus hidup, responsif terhadap tindakan pengguna, dan tetap mempertahankan kecepatan akses instan.
              </p>
            </div>

            {/* Core Pillars Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-dark-850/60 border border-white/5 hover:border-cyan-500/30 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3">
                  <Cpu className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold font-heading text-white mb-1">
                  Fullstack Engine
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Arsitektur backend scalable dengan microservices & API modern.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-dark-850/60 border border-white/5 hover:border-purple-500/30 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-3">
                  <Globe2 className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold font-heading text-white mb-1">
                  Immersive 3D
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Three.js, GLSL custom shaders, dan interaksi spasial 60 FPS.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-dark-850/60 border border-white/5 hover:border-emerald-500/30 transition-colors">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold font-heading text-white mb-1">
                  Clean & Performant
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Audit Lighthouse 95+, SEO ramah mesin telusur, dan bebas bug.
                </p>
              </div>
            </div>

            {/* Animated Statistics Counter */}
            <div className="pt-4 border-t border-white/10">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                {statisticsData.map((stat, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="text-3xl sm:text-4xl font-extrabold font-heading text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                      {hasAnimated ? stat.value : 0}
                      <span>{stat.suffix}</span>
                    </div>
                    <div className="text-xs font-semibold text-white font-heading">
                      {stat.label}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono hidden sm:block">
                      {stat.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Action Button */}
            <div className="pt-2">
              <Button
                href="#contact"
                variant="outline"
                size="md"
                icon={<Mail className="w-4 h-4" />}
              >
                Diskusikan Proyek Anda
              </Button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
