import React, { useState } from 'react';
import { skillCategories, marqueeTechnologies } from '../data/portfolioData';
import { SectionTitle } from '../components/common/SectionTitle';
import { Code2, Award, Trophy, CheckCircle2, ChevronRight, Sparkles } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  code: <Code2 className="w-5 h-5 text-cyan-400" />,
  certificate: <Award className="w-5 h-5 text-cyan-400" />,
  award: <Trophy className="w-5 h-5 text-cyan-400" />,
};

export const SkillsSection: React.FC = () => {
  const [selectedIdx, setSelectedIdx] = useState<number>(0);

  const handleCardClick = (linkHref?: string, idx?: number) => {
    if (idx !== undefined) setSelectedIdx(idx);
    if (linkHref) {
      const target = document.querySelector(linkHref);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section id="skills" className="relative py-24 sm:py-32 bg-[#050510] overflow-hidden">
      {/* Background Ambient Glows */}
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionTitle
          badge="Keahlian & Pencapaian"
          title="Overview &"
          highlightText="Kategori Utama"
          subtitle="Pencapaian nyata karya, sertifikasi tervalidasi, dan kompetensi yang saya kuasai."
        />

        {/* 3 Main Sleek Cards Matching the Photo Exactly */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-7 mb-14">
          {skillCategories.map((cat, idx) => {
            const isSelected = selectedIdx === idx;

            return (
              <div
                key={cat.id || idx}
                onClick={() => setSelectedIdx(idx)}
                className={`
                  relative rounded-3xl p-6 sm:p-7 cursor-pointer select-none
                  transition-all duration-300 ease-out group
                  bg-[#0a1020]/85 backdrop-blur-2xl
                  border ${
                    isSelected
                      ? 'border-cyan-400/80 shadow-[0_10px_35px_-5px_rgba(0,240,255,0.35),inset_0_1px_2px_rgba(255,255,255,0.4)] -translate-y-1'
                      : 'border-slate-700/50 hover:border-cyan-400/50 hover:shadow-[0_8px_30px_rgba(0,240,255,0.2)] hover:-translate-y-1'
                  }
                `}
              >
                {/* Top Metallic Reflection Highlight */}
                <div className="absolute top-0 left-6 right-6 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-300/80 to-transparent pointer-events-none" />

                {/* Top Row: Icon Container on Left, Large Number on Right */}
                <div className="flex items-start justify-between mb-8">
                  {/* Rounded Square Icon Badge */}
                  <div className="w-12 h-12 rounded-2xl bg-[#0e172e] border border-cyan-500/30 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.15)] group-hover:scale-105 transition-transform">
                    {iconMap[cat.iconName] || <Code2 className="w-5 h-5 text-cyan-400" />}
                  </div>

                  {/* Large Bold White Number */}
                  <div className="text-4xl sm:text-5xl font-black font-heading text-white tracking-tight drop-shadow-[0_2px_10px_rgba(255,255,255,0.2)]">
                    {cat.count}
                  </div>
                </div>

                {/* Bottom Row: Uppercase Title & Subtitle */}
                <div className="flex items-end justify-between pt-2">
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold font-mono tracking-widest text-white uppercase group-hover:text-cyan-300 transition-colors">
                      {cat.title}
                    </h3>
                    <p className="text-xs text-slate-400 font-normal mt-1">
                      {cat.subtitle}
                    </p>
                  </div>

                  {/* Quick Scroll Action Button */}
                  {cat.linkHref && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCardClick(cat.linkHref, idx);
                      }}
                      className="p-2 rounded-xl bg-white/5 hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-300 transition-all text-xs flex items-center gap-1 font-mono"
                      title={`Buka ${cat.title}`}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Category Skill Bars Detail */}
        {skillCategories[selectedIdx] && skillCategories[selectedIdx].skills && (
          <div className="rounded-3xl p-6 sm:p-8 bg-dark-850/60 border border-white/10 backdrop-blur-xl relative overflow-hidden transition-all duration-500 mb-16">
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent" />
            
            <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
              <div className="flex items-center gap-2.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#00f0ff]" />
                <h4 className="text-lg font-bold font-heading text-white">
                  Kompetensi Detail: {skillCategories[selectedIdx].title}
                </h4>
              </div>

              {skillCategories[selectedIdx].linkHref && (
                <a
                  href={skillCategories[selectedIdx].linkHref}
                  className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:underline"
                >
                  <span>Lihat semua {skillCategories[selectedIdx].title.toLowerCase()}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              {skillCategories[selectedIdx].skills.map((skill, sIdx) => (
                <div key={sIdx} className="space-y-1.5 p-3 rounded-2xl bg-dark-900/50 border border-white/5">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-200 font-medium flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                      {skill.name}
                      {skill.badge && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-400/10 text-cyan-300 border border-cyan-400/30 ml-1">
                          {skill.badge}
                        </span>
                      )}
                    </span>
                    <span className="text-cyan-400 font-semibold">{skill.level}%</span>
                  </div>

                  <div className="w-full h-1.5 rounded-full bg-dark-950 border border-white/5 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 shadow-[0_0_8px_rgba(0,240,255,0.4)] transition-all duration-700 ease-out"
                      style={{ width: `${skill.level}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Infinite Marquee Running Banner */}
        <div className="pt-6 border-t border-white/5 relative">
          <p className="text-center text-xs font-mono uppercase tracking-widest text-slate-400 mb-6">
            // Terus berevolusi mengikuti standar industri global
          </p>

          <div className="relative overflow-hidden w-full">
            <div className="absolute top-0 bottom-0 left-0 w-24 bg-gradient-to-r from-[#050510] to-transparent z-10 pointer-events-none" />
            <div className="absolute top-0 bottom-0 right-0 w-24 bg-gradient-to-l from-[#050510] to-transparent z-10 pointer-events-none" />

            <div className="flex gap-4 w-max animate-marquee select-none">
              {[...marqueeTechnologies, ...marqueeTechnologies].map((tech, i) => (
                <div
                  key={i}
                  className="px-5 py-2 rounded-xl bg-dark-850/80 border border-white/10 hover:border-cyan-400/40 text-slate-300 hover:text-cyan-300 text-xs sm:text-sm font-mono font-medium transition-colors shadow-sm flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#00f0ff]" />
                  <span>{tech}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
