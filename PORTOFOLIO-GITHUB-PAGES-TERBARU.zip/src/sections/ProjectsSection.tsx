import React, { useState } from 'react';
import { projectsData } from '../data/portfolioData';
import { ProjectItem } from '../types';
import { SectionTitle } from '../components/common/SectionTitle';
import { GlassCard } from '../components/common/GlassCard';
import { Button } from '../components/common/Button';
import { ProjectModal } from '../components/common/ProjectModal';
import { ExternalLink, Github, Eye, Sparkles, Filter } from 'lucide-react';

const categories = ['Semua', 'Web 3D', 'Fullstack', 'UI/Frontend'] as const;

export const ProjectsSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeModalProject, setActiveModalProject] = useState<ProjectItem | null>(null);

  const filteredProjects = selectedCategory === 'Semua'
    ? projectsData
    : projectsData.filter((p) => p.category === selectedCategory);

  return (
    <section id="projects" className="relative py-24 sm:py-32 bg-[#050510] overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-1/3 left-1/4 w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionTitle
          badge="Showcase Karya Terpilih"
          title="Eksplorasi Proyek"
          highlightText="Inovatif & 3D"
          subtitle="Dari aplikasi 3D WebGL interaktif hingga sistem arsitektur fullstack skala enterprise."
        />

        {/* Filter Categories Pill Bar */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-12 sm:mb-16">
          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-slate-400 mr-2">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span>Kategori:</span>
          </div>

          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-5 py-2 rounded-full text-xs sm:text-sm font-heading font-medium transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-cyan-500 text-dark-950 font-bold shadow-[0_0_20px_rgba(0,240,255,0.4)] scale-105'
                  : 'bg-dark-850/80 border border-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredProjects.map((project) => (
            <GlassCard
              key={project.id}
              glowColor={project.category === 'Web 3D' ? 'cyan' : 'purple'}
              cornerAccents={true}
              tiltEffect={true}
              onClick={() => setActiveModalProject(project)}
              className="flex flex-col h-full group"
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-[16/10] overflow-hidden rounded-t-2xl bg-dark-950">
                <img
                  src={project.thumbnail}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-transparent to-transparent opacity-90" />

                {/* Category Pill */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-dark-900/80 backdrop-blur-md border border-cyan-500/30 text-cyan-300 text-[11px] font-mono shadow-[0_0_10px_rgba(0,240,255,0.2)]">
                    {project.category}
                  </span>
                  {project.featured && (
                    <span className="px-2.5 py-1 rounded-full bg-purple-500/20 backdrop-blur-md border border-purple-500/30 text-purple-300 text-[10px] font-mono flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-purple-400" />
                      Featured
                    </span>
                  )}
                </div>

                {/* Hover Quick View Trigger Icon */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-dark-950/40 backdrop-blur-[2px]">
                  <span className="px-4 py-2 rounded-xl bg-dark-900/90 border border-cyan-400 text-cyan-300 text-xs font-heading font-semibold flex items-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.4)]">
                    <Eye className="w-4 h-4" />
                    Buka Detail Proyek
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex flex-col flex-grow justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold font-heading text-white group-hover:text-cyan-300 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-slate-400 text-sm line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Tech Pills */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {project.technologies.slice(0, 4).map((tech, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg bg-white/5 text-slate-300 text-[11px] font-mono border border-white/5"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.technologies.length > 4 && (
                    <span className="px-2 py-1 rounded-lg bg-cyan-500/10 text-cyan-400 text-[11px] font-mono">
                      +{project.technologies.length - 4}
                    </span>
                  )}
                </div>

                {/* Action Links */}
                <div
                  className="pt-4 border-t border-white/5 flex items-center justify-between"
                  onClick={(e) => e.stopPropagation()}
                >
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Live Demo</span>
                  </a>

                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-mono text-slate-400 hover:text-white transition-colors"
                  >
                    <Github className="w-3.5 h-3.5" />
                    <span>GitHub</span>
                  </a>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>

        {/* Modal for detail preview */}
        <ProjectModal
          project={activeModalProject}
          onClose={() => setActiveModalProject(null)}
        />
      </div>
    </section>
  );
};
