import React, { useState } from 'react';
import { certificatesData } from '../data/portfolioData';
import { CertificateItem } from '../types';
import { SectionTitle } from '../components/common/SectionTitle';
import { GlassCard } from '../components/common/GlassCard';
import { CertificateModal } from '../components/common/CertificateModal';
import { Award, ExternalLink, Eye, CheckCircle2 } from 'lucide-react';

export const CertificatesSection: React.FC = () => {
  const [selectedCert, setSelectedCert] = useState<CertificateItem | null>(null);

  return (
    <section id="certificates" className="relative py-24 sm:py-32 bg-[#050510] overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionTitle
          badge="Kredensial & Lisensi"
          title="Sertifikasi &"
          highlightText="Pencapaian Resmi"
          subtitle="Bukti penguasaan teknologi teruji dari platform sertifikasi global bereputasi tinggi."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certificatesData.map((cert) => (
            <GlassCard
              key={cert.id}
              glowColor="purple"
              cornerAccents={true}
              tiltEffect={true}
              onClick={() => setSelectedCert(cert)}
              className="flex flex-col h-full group"
            >
              {/* Image Thumbnail */}
              <div className="relative aspect-[16/10] overflow-hidden rounded-t-2xl bg-dark-950">
                <img
                  src={cert.image}
                  alt={cert.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-transparent to-transparent opacity-85" />

                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 rounded-full bg-dark-900/80 backdrop-blur-md border border-purple-500/30 text-purple-300 text-[10px] font-mono flex items-center gap-1 shadow-sm">
                    <Award className="w-3 h-3 text-purple-400" />
                    Verified
                  </span>
                </div>

                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-dark-950/40 backdrop-blur-[2px]">
                  <span className="p-2.5 rounded-full bg-dark-900/90 border border-purple-400 text-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.4)]">
                    <Eye className="w-4 h-4" />
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex flex-col flex-grow justify-between space-y-4">
                <div>
                  <div className="text-[11px] font-mono text-cyan-400 mb-1">
                    {cert.issuer} • {cert.date}
                  </div>
                  <h3 className="text-base font-bold font-heading text-white group-hover:text-purple-300 transition-colors line-clamp-2">
                    {cert.title}
                  </h3>
                </div>

                {/* Skills tags */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {cert.skills.slice(0, 3).map((s, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-white/5 text-slate-300 text-[10px] font-mono"
                    >
                      {s}
                    </span>
                  ))}
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs font-mono text-slate-400">
                  <span className="text-[10px]">ID: {cert.credentialId.slice(0, 10)}...</span>
                  <span className="text-purple-400 group-hover:underline flex items-center gap-1">
                    Detail <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>

        {/* Lightbox Modal */}
        <CertificateModal
          certificate={selectedCert}
          onClose={() => setSelectedCert(null)}
        />
      </div>
    </section>
  );
};
