import React from 'react';
import { experienceData } from '../data/portfolioData';
import { SectionTitle } from '../components/common/SectionTitle';
import { GlassCard } from '../components/common/GlassCard';
import { Briefcase, GraduationCap, MapPin, Calendar, Sparkles } from 'lucide-react';

export const ExperienceSection: React.FC = () => {
  return (
    <section id="experience" className="relative py-24 sm:py-32 bg-[#050510] overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionTitle
          badge="Jejak Karir & Edukasi"
          title="Pengalaman Kerja &"
          highlightText="Pendidikan"
          subtitle="Perjalanan profesional dan dedikasi berkelanjutan dalam rekayasa perangkat lunak modern."
        />

        {/* Vertical Timeline Container */}
        <div className="relative mt-16">
          {/* Glowing Central Vertical Line */}
          <div className="absolute left-4 md:left-1/2 top-4 bottom-4 -translate-x-1/2 w-0.5 bg-gradient-to-b from-cyan-400 via-purple-500 to-cyan-500 shadow-[0_0_12px_rgba(0,240,255,0.6)]" />

          <div className="space-y-12">
            {experienceData.map((item, index) => {
              const isEven = index % 2 === 0;

              return (
                <div
                  key={item.id}
                  className={`relative flex flex-col md:flex-row items-start md:items-center ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  {/* Central Node Badge */}
                  <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-dark-900 border-2 border-cyan-400 shadow-[0_0_15px_#00f0ff] flex items-center justify-center text-cyan-300 z-10">
                    {item.type === 'experience' ? (
                      <Briefcase className="w-4 h-4" />
                    ) : (
                      <GraduationCap className="w-4 h-4" />
                    )}
                  </div>

                  {/* Card Content Column (Width 50%) */}
                  <div
                    className={`w-full md:w-[calc(50%-40px)] pl-14 md:pl-0 ${
                      isEven ? 'md:pr-0 md:text-left' : 'md:pl-0'
                    }`}
                  >
                    <GlassCard
                      glowColor={item.type === 'experience' ? 'cyan' : 'purple'}
                      cornerAccents={true}
                      tiltEffect={true}
                      className="p-6 sm:p-7"
                    >
                      {/* Period & Featured Badge */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono">
                          <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                          {item.period}
                        </span>

                        {item.featuredBadge && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[11px] font-mono">
                            <Sparkles className="w-3 h-3 text-purple-400" />
                            {item.featuredBadge}
                          </span>
                        )}
                      </div>

                      {/* Role & Company */}
                      <h3 className="text-xl font-bold font-heading text-white">
                        {item.role}
                      </h3>
                      <h4 className="text-sm font-semibold text-cyan-400 mb-1">
                        {item.company}
                      </h4>
                      <p className="flex items-center gap-1.5 text-xs text-slate-400 font-mono mb-4">
                        <MapPin className="w-3.5 h-3.5 text-slate-500" />
                        {item.location}
                      </p>

                      {/* Description List */}
                      <ul className="space-y-2 mb-5">
                        {item.description.map((desc, dIdx) => (
                          <li
                            key={dIdx}
                            className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300 leading-relaxed"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
                            <span>{desc}</span>
                          </li>
                        ))}
                      </ul>

                      {/* Tech Stack Tags */}
                      <div className="pt-3 border-t border-white/5 flex flex-wrap gap-1.5">
                        {item.techStack.map((tech, tIdx) => (
                          <span
                            key={tIdx}
                            className="px-2.5 py-0.5 rounded-md bg-dark-950 text-slate-400 text-[11px] font-mono border border-white/5"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </GlassCard>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
