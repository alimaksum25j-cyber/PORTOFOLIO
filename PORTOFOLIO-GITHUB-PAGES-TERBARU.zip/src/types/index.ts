export interface ProjectItem {
  id: string;
  title: string;
  category: 'Web 3D' | 'Fullstack' | 'UI/Frontend';
  tagline: string;
  description: string;
  longDescription: string;
  thumbnail: string;
  gallery: string[];
  technologies: string[];
  features: string[];
  stats?: { label: string; value: string }[];
  liveUrl: string;
  githubUrl: string;
  featured?: boolean;
}

export interface SkillCategory {
  id: string;
  title: string;
  subtitle: string;
  count: number;
  iconName: string;
  linkHref?: string;
  skills: {
    name: string;
    level: number; // percentage
    highlight?: boolean;
    badge?: string;
  }[];
}

export interface ExperienceItem {
  id: string;
  period: string;
  role: string;
  company: string;
  location: string;
  type: 'experience' | 'education';
  description: string[];
  techStack: string[];
  featuredBadge?: string;
}

export interface CertificateItem {
  id: string;
  title: string;
  issuer: string;
  date: string;
  credentialId: string;
  image: string;
  verifyUrl: string;
  skills: string[];
}

export interface StatisticItem {
  value: number;
  suffix: string;
  label: string;
  description: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}
