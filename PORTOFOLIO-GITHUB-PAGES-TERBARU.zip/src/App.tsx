import React, { useState } from 'react';
import { useLenis } from './hooks/useLenis';
import { Preloader } from './components/common/Preloader';
import { CustomCursor } from './components/common/CustomCursor';
import { Navbar } from './components/navbar/Navbar';
import { HeroSection } from './sections/HeroSection';
import { AboutSection } from './sections/AboutSection';
import { SkillsSection } from './sections/SkillsSection';
import { ProjectsSection } from './sections/ProjectsSection';
import { ExperienceSection } from './sections/ExperienceSection';
import { CertificatesSection } from './sections/CertificatesSection';
import { ContactSection } from './sections/ContactSection';
import { Footer } from './sections/Footer';

export const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  // Initialize Lenis smooth scroll
  useLenis(!isLoading);

  return (
    <div className="relative min-h-screen bg-[#050510] text-slate-100 selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Custom Glowing Cursor (Desktop Mouse Only) */}
      <CustomCursor />

      {/* Cyber Preloader */}
      {isLoading && <Preloader onComplete={() => setIsLoading(false)} />}

      {/* Fixed Futuristic Glass Navbar */}
      <Navbar />

      {/* Main Portfolio Sections */}
      <main className="relative">
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <ProjectsSection />
        <ExperienceSection />
        <CertificatesSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default App;
